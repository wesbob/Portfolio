create function populate_dim_date(start_date date DEFAULT '2023-01-01'::date, end_date date DEFAULT '2027-12-31'::date) returns void
    language plpgsql
as
$$
DECLARE
    curr_date DATE := start_date;  -- Changed from current_date to curr_date
BEGIN
    WHILE curr_date <= end_date LOOP
        INSERT INTO dim_date (
            date_key,
            full_date,
            day_of_week,
            day_name,
            day_of_month,
            week_of_year,
            month_number,
            month_name,
            quarter,
            year,
            is_weekend
        )
        VALUES (
            TO_CHAR(curr_date, 'YYYYMMDD')::INT,
            curr_date,
            EXTRACT(DOW FROM curr_date)::INT,
            TO_CHAR(curr_date, 'Day'),
            EXTRACT(DAY FROM curr_date)::INT,
            EXTRACT(WEEK FROM curr_date)::INT,
            EXTRACT(MONTH FROM curr_date)::INT,
            TO_CHAR(curr_date, 'Month'),
            EXTRACT(QUARTER FROM curr_date)::INT,
            EXTRACT(YEAR FROM curr_date)::INT,
            CASE WHEN EXTRACT(DOW FROM curr_date) IN (0, 6) THEN TRUE ELSE FALSE END
        );

        curr_date := curr_date + INTERVAL '1 day';
    END LOOP;
END;
$$;

alter function populate_dim_date(date, date) owner to postgres;

