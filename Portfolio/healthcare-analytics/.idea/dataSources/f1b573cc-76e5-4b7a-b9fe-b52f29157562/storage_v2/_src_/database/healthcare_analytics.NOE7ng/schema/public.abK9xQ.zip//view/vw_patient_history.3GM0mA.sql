create view vw_patient_history
            (patient_id, age, insurance_type, total_appointments, completed_appointments, no_shows, cancellations,
             patient_no_show_rate)
as
SELECT p.patient_id,
       p.age,
       p.insurance_type,
       count(*)                                          AS total_appointments,
       sum(
               CASE
                   WHEN f.is_completed THEN 1
                   ELSE 0
                   END)                                  AS completed_appointments,
       sum(
               CASE
                   WHEN f.is_no_show THEN 1
                   ELSE 0
                   END)                                  AS no_shows,
       sum(
               CASE
                   WHEN f.is_cancelled THEN 1
                   ELSE 0
                   END)                                  AS cancellations,
       round(100.0 * sum(
               CASE
                   WHEN f.is_no_show THEN 1
                   ELSE 0
                   END)::numeric / count(*)::numeric, 2) AS patient_no_show_rate
FROM dim_patients p
         JOIN fact_appointments f ON p.patient_key = f.patient_key
GROUP BY p.patient_id, p.age, p.insurance_type
ORDER BY (count(*)) DESC;

alter table vw_patient_history
    owner to postgres;

