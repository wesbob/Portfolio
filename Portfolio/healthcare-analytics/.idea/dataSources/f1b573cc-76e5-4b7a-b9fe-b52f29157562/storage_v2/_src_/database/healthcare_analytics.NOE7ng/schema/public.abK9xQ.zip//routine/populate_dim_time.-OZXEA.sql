create function populate_dim_time() returns void
    language plpgsql
as
$$
DECLARE
    hour_val INT := 0;
    minute_val INT := 0;
    time_val TIME;
    time_key_val INT;
BEGIN
    WHILE hour_val < 24 LOOP
        minute_val := 0;
        WHILE minute_val < 60 LOOP
            time_val := (LPAD(hour_val::TEXT, 2, '0') || ':' || LPAD(minute_val::TEXT, 2, '0') || ':00')::TIME;
            time_key_val := hour_val * 100 + minute_val;

            INSERT INTO dim_time (
                time_key,
                time_value,
                hour,
                minute,
                time_period,
                business_hour
            )
            VALUES (
                time_key_val,
                time_val,
                hour_val,
                minute_val,
                CASE
                    WHEN hour_val < 12 THEN 'Morning'
                    WHEN hour_val < 17 THEN 'Afternoon'
                    ELSE 'Evening'
                END,
                CASE WHEN hour_val BETWEEN 8 AND 16 THEN TRUE ELSE FALSE END
            );

            minute_val := minute_val + 30; -- 30-minute intervals
        END LOOP;

        hour_val := hour_val + 1;
    END LOOP;
END;
$$;

alter function populate_dim_time() owner to postgres;

