create view vw_peak_appointment_hours
            (day_name, hour, time_period, appointment_count, completed_count, completion_rate) as
SELECT dd.day_name,
       dt.hour,
       dt.time_period,
       count(*)                                          AS appointment_count,
       sum(
               CASE
                   WHEN f.is_completed THEN 1
                   ELSE 0
                   END)                                  AS completed_count,
       round(100.0 * sum(
               CASE
                   WHEN f.is_completed THEN 1
                   ELSE 0
                   END)::numeric / count(*)::numeric, 2) AS completion_rate
FROM fact_appointments f
         JOIN dim_date dd ON f.appointment_date_key = dd.date_key
         JOIN dim_time dt ON f.appointment_time_key = dt.time_key
GROUP BY dd.day_name, dd.day_of_week, dt.hour, dt.time_period
ORDER BY dd.day_of_week, dt.hour;

alter table vw_peak_appointment_hours
    owner to postgres;

