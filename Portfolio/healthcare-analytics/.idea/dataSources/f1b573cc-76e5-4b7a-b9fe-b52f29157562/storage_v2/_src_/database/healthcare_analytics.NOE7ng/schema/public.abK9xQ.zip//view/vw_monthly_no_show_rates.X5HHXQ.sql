create view vw_monthly_no_show_rates (clinic_name, year, month_name, total_appointments, no_shows, no_show_rate_pct) as
SELECT c.clinic_name,
       d.year,
       d.month_name,
       count(*)                                          AS total_appointments,
       sum(
               CASE
                   WHEN f.is_no_show THEN 1
                   ELSE 0
                   END)                                  AS no_shows,
       round(100.0 * sum(
               CASE
                   WHEN f.is_no_show THEN 1
                   ELSE 0
                   END)::numeric / count(*)::numeric, 2) AS no_show_rate_pct
FROM fact_appointments f
         JOIN dim_clinics c ON f.clinic_key = c.clinic_key
         JOIN dim_date d ON f.appointment_date_key = d.date_key
GROUP BY c.clinic_name, d.year, d.month_name, d.month_number
ORDER BY d.year, d.month_number, c.clinic_name;

alter table vw_monthly_no_show_rates
    owner to postgres;

